<html>
<body>
<center>
<h2>JayKay's Hub</h2>

<form method="POST" enctype="multipart/form-data">
  <br>
   Movies:<br>
  <select name="movie">
    <option value="1">Yes</option>
    <option value="0">No</option>
  </select>
  <br>
   WebSeries:<br>
  <select name="webseries">
    <option value="1" >Yes</option>
    <option value="0">No</option>
  </select>
  
  <br>
   Name:<br>
  <input type="text" name="name" required placeholder="Movie/Series Name">
  <br><br>
  Price:<br>
  <input type="text" name="about" placeholder="About " required>
  <br>
  <br>
  Link:<br>
  <input type="text" name="link" placeholder="Link " required>
  <br>
  <br>
  Image:<br>
  <input type="file" name="image1" required><br><br>
  <input type="submit" value="Submit" name="Submit">
</center></form> 
</body>
</html>


<?php 
if (isset($_POST['Submit'])){
$name=$_POST['name'];
$webseries=$_POST['webseries'];
$movie=$_POST['movie'];
$image = $_FILES['image1']['name'];
$fileElementName = 'image1';
$path = '../assets/img/'; 
$location = $path . $_FILES['image1']['name']; 
move_uploaded_file($_FILES['image1']['tmp_name'], $location); 
$about=$_POST['about'];
$link=$_POST['link'];
$conn=mysqli_connect("localhost","id8733186_kpt_user","fake1234","id8733186_kpt");
$ins="INSERT INTO `movies`(`name`,`image`,`about`,`link`,`movie`,`webseries`) VALUES ('$name','$image','$about','$link','$movie','$webseries')";
if(mysqli_query($conn,$ins))
echo"<center><h1>Inserted successfully</h1></center>";
else
echo "<center>Not inserted</center>";
// mysqli_query($conn,$ins);
}
?>
